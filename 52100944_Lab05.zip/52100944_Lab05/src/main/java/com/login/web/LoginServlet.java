package com.login.web;


import java.io.IOException;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import com.login.bean.*;
import com.login.database.*;

@WebServlet(urlPatterns = "/index")
public class LoginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private LoginDao loginDao;

    public void init() {
        loginDao = new LoginDao();
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {

        String username = request.getParameter("username");
        String password = request.getParameter("password");
        LoginBean loginBean = new LoginBean();
        loginBean.setUsername(username);
        loginBean.setPassword(password);
        
        try {
            if (loginDao.validate(loginBean)) {
            	Cookie name = new Cookie("username", username);
                Cookie pass = new Cookie("password", password);
                name.setMaxAge(60*60*24*30);
                pass.setMaxAge(60*60*24*30);
            	response.addCookie(name);
            	response.addCookie(pass);
                response.sendRedirect("home.http");
                return;
            } else {
            	RequestDispatcher rd = request.getRequestDispatcher("index.http");
                System.out.println("<font color=red>Either user name or password is wrong.</font>");
                rd.include(request, response);
            }
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
}