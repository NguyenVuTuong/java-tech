﻿package com.demoSpringMVC.lab08;
import java.net.*;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

import HomeController.HomeController;

@SpringBootApplication
@ComponentScan(basePackageClasses = HomeController.class)
public class Lab08Application {
	public static void main(String[] args) {
		SpringApplication.run(Lab08Application.class, args);
	}

}
