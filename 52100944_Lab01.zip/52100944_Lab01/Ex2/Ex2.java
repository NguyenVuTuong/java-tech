import vn.edu.tdtu.ArrayOutput;
import vn.edu.tdtu.ArrayHandler;

public class Ex2{
    public static void main(String args[]){
        int a[] = {12, 2, 34, 5, 6};
        int b[] = {1, 2, 3, 4, 5};

        //print
        ArrayOutput.print(a);
        ArrayOutput.print(b);

        //merge
        int c[] = ArrayHandler.merge(a,b);
        ArrayOutput.print(c);

        //Sort
        ArrayHandler.sort(c);
        ArrayOutput.print(c);

        //Write
        String s = ("output.txt");
        ArrayOutput.write(c, s);
    }
}