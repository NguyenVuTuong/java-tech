public class Program {
    public static void main(String[] args) {
        
        if(args.length == 3) {
            char operator = args[1].charAt(0);
            
            if(operator == '+') {
                int kq = Integer.valueOf(args[0]) + Integer.valueOf(args[2]);
                System.out.println(kq);
            }
            else if(operator == '-') {
                int kq = Integer.valueOf(args[0]) - Integer.valueOf(args[2]);
                System.out.println(kq);
            }
            else if(operator == 'x') {
                int kq = Integer.valueOf(args[0]) * Integer.valueOf(args[2]);
                System.out.println(kq);
            }
            else if(operator == '/') {
                double kq = Double.valueOf(args[0]) / Double.valueOf(args[2]);
                System.out.println(kq);
            }
            else if(operator == '^') {
                int a =  Integer.valueOf(args[0]);
                int b = Integer.valueOf(args[2]);
                int kq = (int) Math.pow(a, b);
                System.out.println(kq);
            }
            else {
                System.out.println("Unsupported operator");
            }
        }
        else {
            System.out.println("Invalid expression");
        }
    }
}