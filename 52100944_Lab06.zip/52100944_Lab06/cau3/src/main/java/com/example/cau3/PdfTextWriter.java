package com.example.cau3;

public class PdfTextWriter implements TextWriter {
    @Override
    public void write(String fileName, String text) {

    }
}
