package com.example.cau3;

public interface TextWriter {
    void write(String fileName, String text);
}
