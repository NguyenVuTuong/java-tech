package com.example.cau4;

public interface TextWriter {
    void write(String fileName, String text);
}
